package com.studenttransportation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentTransportationApplicationTests {

	@Test
	void contextLoads() {
	}

}
