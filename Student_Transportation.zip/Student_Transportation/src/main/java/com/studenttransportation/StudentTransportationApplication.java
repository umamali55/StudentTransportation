package com.studenttransportation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentTransportationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentTransportationApplication.class, args);
	}

}
